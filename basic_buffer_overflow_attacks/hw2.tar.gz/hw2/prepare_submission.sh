#!/bin/bash

# Ensure zip is installed
if ! command -v zip &> /dev/null; then
    echo "zip command not found. Installing zip..."
    sudo wget https://archive.kali.org/archive-keyring.gpg -O /usr/share/keyrings/kali-archive-keyring.gpg
    sudo apt update && sudo apt install -y zip
    if [ $? -ne 0 ]; then
        echo "Failed to install zip. Exiting."
        exit 1
    fi
fi

# Define the output zip file
ZIP_FILE="submission.zip"

# Define the list of files to zip
FILES=(
    "cookie"
    "sol1.py"
    "sol2.py"
    "sol3.py"
    "sol4.py"
)

# Create the zip archive
zip -r "$ZIP_FILE" "${FILES[@]}"

# Check if the zip operation was successful
if [ $? -eq 0 ]; then
    echo "Files successfully zipped into $ZIP_FILE"
else
    echo "Error occurred while creating zip file."
    exit 1
fi

