#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int mycopy(char *arg, char *out)
{
  strcpy(out, arg);
  return 0;
}

int func(char *argv[])
{
  char buf[V3BUFFER];
  mycopy(argv[1], buf);
}

int _main(int argc, char *argv[])
{
  if (argc != 2)
    {
      fprintf(stderr, "vulnerable3: argc != 2\n");
      exit(EXIT_FAILURE);
    }
  func(argv);
  return 0;
}
