#!/usr/bin/python3

import random
import sys

# Grab sid
try:
    infile = open('./cookie', 'r')
    sid = infile.read().strip("\n")
    infile.close()
except FileNotFoundError:
    print('ERROR: Set the cookie first!', file=sys.stderr)
    sys.exit(1)

random.seed(sid)
print(f"{sid}")

# Generate basic target
def gen_target(num, reps):
    ft = open(f"./base/vulnerable{num}.c", 'r')
    fto = open(f"./vulnerable{num}.c", 'w')
    t = ft.readlines()
    ft.close()
    for l in t:
        for (v, t) in reps:
            l = l.replace(v, t)
        fto.write(l)
    fto.close()

# Setup vulnerable1
v1_replace = "V1BUFFER"
v1_val = str(random.randint(len(sid) + 4, len(sid) + 12))

# Setup vulnerable2
v2_replace = "V2BUFFER"
v2_val = str(4*random.randrange(1, 5))

# Setup vulnerable3
v3_replace = "V3BUFFER"
v3_val = str(128*random.randrange(1,7))

# Setup vulnerable4
v4_replace = "V4BUFFER"
v4_val = str(random.randint(100, 207))

# Generate targets
gen_target("1", [(v1_replace, v1_val)])
gen_target("2", [(v2_replace, v2_val)])
gen_target("3", [(v3_replace, v3_val)])
gen_target("4", [(v4_replace, v4_val)])
