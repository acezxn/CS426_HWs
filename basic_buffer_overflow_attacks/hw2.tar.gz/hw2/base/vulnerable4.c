#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void nstrcpy(char *out, int outl, char *in)
{
  int i, len;

  len = strlen(in);
  if (len > outl)
    len = outl;

  for (i = 0; i <= len; i++)
    out[i] = in[i];
}

void process(char *arg)
{
  char buf[V4BUFFER];

  nstrcpy(buf, sizeof buf, arg);
}

void func(char *argv[])
{
  process(argv[1]);
}

int _main(int argc, char *argv[])
{
  if (argc != 2)
    {
      fprintf(stderr, "vulnerable4: argc != 2\n");
      exit(EXIT_FAILURE);
    }
  func(argv);
  return 0;
}
