#include <stdio.h>
#include <string.h>

void vulnerable(char *arg)
{
	int *p;
	int a;
	char buf[V1BUFFER];

	fprintf(stderr, "%s\n", buf);

	strncpy(buf, arg, sizeof(buf) + 8);

	if (p != 0) *p = a;
}

void call_vul(char *arg)
{
	char temp[37];
	vulnerable(arg);
}

int _main(int argc, char **argv)
{
	if (argc != 2) {
		fprintf(stderr, "Error: need a command-line argument\n");
		return 1;
	}
	call_vul(argv[1]);
	return 0;
}
