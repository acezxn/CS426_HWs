#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/random.h>
#include <unistd.h>

#define MAX_PAD 0x100000

int main(int argc, char *argv[], char *envp[])
{
#ifdef NO_RANDOMIZATION
    // For vulnerable4, set a fixed stack goal without randomization
    char *stack_goal = (char *) 0xBFFF1000;
#else
    // Standard behavior: Set a randomized stack goal
#ifdef STACK_GOAL
    char *stack_goal = (char *) STACK_GOAL;
#else
    char *stack_goal = (char *) 0xBFFF0000 - COOKIE;
#endif

#ifdef MINIASLR
    // Randomize stack pointer for other targets
    unsigned int r;
    getentropy(&r, sizeof(unsigned int));
    stack_goal -= r & 0xFF;
#endif
#endif // End NO_RANDOMIZATION check

    char *esp = alloca(0);
    if ((esp < stack_goal) || (esp - stack_goal > MAX_PAD)) {
        fprintf(stderr, "Can't normalize stack position %p to %p\n", esp, stack_goal);
        return 1;
    }
    alloca(esp - stack_goal);

    // Move argv from top of stack to here, and clear envp, to prevent shortcuts.
    char **_argv = alloca(sizeof(char *) * (argc + 1));
    _argv[argc] = NULL;
    for (int i = argc - 1; i >= 0; i--) {
        size_t len = strlen(argv[i]) + 1;
        _argv[i] = alloca(len);
        strncpy(_argv[i], argv[i], len);
        memset(argv[i], 0, len);
        argv[i] = NULL;
    }
    argv = NULL;

    char **_envp = alloca(sizeof(char *));
    _envp[0] = NULL;
    for (int i = 0; envp[i] != 0; i++) {
        size_t len = strlen(envp[i]) + 1;
        memset(envp[i], 0, len);
        envp[i] = NULL;
    }
    envp = NULL;

    // Further stack normalization to prevent argument size from affecting ESP
    stack_goal -= (MAX_PAD >> 1);
    esp = alloca(0);
    if ((esp < stack_goal) || (esp - stack_goal > MAX_PAD)) {
        fprintf(stderr, "Can't normalize stack position %p to %p\n", esp, stack_goal);
        return 1;
    }

    alloca(esp - stack_goal);

    // Preserve stack integrity with a canary
    volatile int canary = 0xB000DEAD;
    int ret = _main(argc, _argv, _envp);

    if (canary != 0xB000DEAD) {
        fprintf(stderr, "Uh oh, the canary is dead.\n"
                        "Don't overwrite the stack frame for main().\n");
    }
    return ret;
}

